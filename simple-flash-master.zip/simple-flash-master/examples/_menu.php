<ul>
    <li><a href="./">Bootstrap 3</a></li>
    <li><a href="./bootstrap4.php">Bootstrap 4</a></li>
    <li><a href="./foundation5.php">Foundation 5</a></li>
    <li><a href="./foundation6.php">Foundation 6</a></li>
    <li><a href="./semantic2.php">Semantic UI 2</a></li>
    <li><a href="./uikit2.php">UIKit 2</a></li>
    <li><a href="./custom.php">Custom Template</a></li>
</ul>
