# Changelog

All Notable changes to `tamtamchik/simple-flash` will be documented in this file.

Updates should follow the [Keep a CHANGELOG](http://keepachangelog.com/) principles.

## 1.1.2 - 2016-03-19

### Changed
- Removed `FlashInterface`. It was causing troubles. 

## 1.1.1 - 2016-03-14

### Added
- `FlashInterface`

## 1.1.0 - 2016-03-13

### Added
- Templates

## 1.0.1 - 2015-12-20

### Fixed
- Don't allow instantiation

## 1.0.0 - 2015-08-14

### Added
- Bumped version to 1.0.0

## 0.4.2 - 2015-05-30

### Added
- Support for array as `$message` variable.

## 0.4.1 - 2015-05-29

### Fixed
- Singleton instance.
- Empty `$message` bug.

## 0.4.0 - 2015-05-28

### Added
- New namespace `\Tamtamchik\SimpleFlash\Flash`.

### Deprecated
- Old namespace `\Tamtamchik\Flash\Flash`.

## 0.3.2 - 2015-05-28

### Added
- Initial version
