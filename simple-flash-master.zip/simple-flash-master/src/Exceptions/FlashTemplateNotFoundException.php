<?php

namespace Tamtamchik\SimpleFlash\Exceptions;

/**
 * Class FlashTemplateNotFoundException.
 * Thrown when factory can't find a template.
 */
class FlashTemplateNotFoundException extends \Exception { }
